/* define ctrl class */

#ifndef __FP_H__
#define __FP_H__

#include <iostream>
#include <ctype.h>
#include "fpmath.h"
using namespace std;

#endif
